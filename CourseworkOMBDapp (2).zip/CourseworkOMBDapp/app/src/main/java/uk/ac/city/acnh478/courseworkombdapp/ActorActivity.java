package uk.ac.city.acnh478.courseworkombdapp;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

//Intent intent115 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.imdb.com/find?ref_=nv_sr_fn&q=" +actorWord"&s=nm"));
public class ActorActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actor_activity);
        String goWord = getIntent().getExtras().getString("actorTitle");
        goWord = goWord.replaceAll("\\s", "+");//if there are many words on the search of the user, the spaces will be replaces with + signs in order to be able to implement the keyword properly into the URL
        final String example=goWord;
        Button searchActorBtn = (Button) findViewById(R.id.button);
        searchActorBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.imdb.com/find?q="+example+"&s=nm&exact=true&ref_=fn_nm_ex"));
                    startActivity(intent);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

    }

    public void backToSearchActivity(View view) {
        Intent intent = new Intent(this, uk.ac.city.acnh478.courseworkombdapp.MainActivity.class);
        startActivity(intent);
    }
}
