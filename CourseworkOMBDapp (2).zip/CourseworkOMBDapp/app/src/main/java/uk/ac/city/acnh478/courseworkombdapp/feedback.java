package uk.ac.city.acnh478.courseworkombdapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;


public class feedback extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feedback_activity);
    }
    public void backToSearchActivityfromFeedback(View view){
        Intent intent = new Intent(this, uk.ac.city.acnh478.courseworkombdapp.MainActivity.class);
        startActivity(intent);
    }

    public void submitData (View view) {
        MessageBox("Thanks for submitting feedback!");
        Intent inten2 = new Intent(this, MainActivity.class);
        startActivity(inten2);

    }
    public void MessageBox(String message)
    {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}

