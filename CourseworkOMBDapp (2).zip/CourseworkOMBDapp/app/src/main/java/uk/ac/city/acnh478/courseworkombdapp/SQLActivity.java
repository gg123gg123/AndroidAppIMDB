package uk.ac.city.acnh478.courseworkombdapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLActivity extends SQLiteOpenHelper{
public static final String DB_NAME = "movieDataBase.db";
    public static final int DB_VERSION = 1;
    public static final String TABLE_NAME = "movieDatabase";
    public static final String COL_ID = "movie_id";
    public static final String COL_JSON = "movie_result";


    public SQLActivity(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String TABLE_CREATE = "CREATE TABLE "+ TABLE_NAME + " (" + COL_ID + " TEXT, " + COL_JSON + " TEXT)";
        db.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertMovieData(String keyword,String jsonResult) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ID, keyword);
        cv.put(COL_JSON, jsonResult);
        db.insert(TABLE_NAME, null, cv);
        db.close();
    }

    public String getMovieData (String keyword) {
        SQLiteDatabase db = this.getReadableDatabase();
        String movieQuery = "SELECT movie_result FROM movieDatabase WHERE movie_id= '" + keyword + "'";
        Cursor cursor = db.rawQuery(movieQuery,null);
        String listResult = null;
        while (cursor.moveToNext()){
            listResult =cursor.getString(0);
        }
        cursor.close();
        db.close();
        return listResult;
    }
}


