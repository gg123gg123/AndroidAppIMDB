package uk.ac.city.acnh478.courseworkombdapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

/*There has been an addition of messages on click (Toasts) which tells the user what
the application is doing when they click a button on certain screens. The messages serve the
purpose of enabling a basic understanding of their actions on the application. An other feature
was the introduction of a feedback screen where users were able to input their name, score rating (/10)
and a comment on the application. Upon submitting their feedback the user sees another toast message
saying "Thanks for submitting feedback!". However the feature lacks the additional functionality which
would allow the results to saved to a database (either online or offline). The final feature is the
onclick searching for the names of actors by running a query on the IMDB actor/actress search page.
Many thanks*/
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }


    public void MovieMessageBox(String message)
    {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    public void ActorMessageBox(String message)
    {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    public void FeedbackMessageBox(String message)
    {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    public void toResultsActivity(View view) {
        EditText movieTitle = (EditText) findViewById(R.id.film_title);
        String title = movieTitle.getText().toString();

        Intent intent = new Intent(this, uk.ac.city.acnh478.courseworkombdapp.ResActivity.class);
        MovieMessageBox("Finding movie from database or searching omdbapi.com");
        intent.putExtra("movieTitle", title);

        startActivity(intent);

    }

    public void toActorActivity(View View) {
        EditText actorTitle = (EditText) findViewById(R.id.actor_title);
        String title = actorTitle.getText().toString();

        Intent intent115 = new Intent(this, uk.ac.city.acnh478.courseworkombdapp.ActorActivity.class);
        intent115.putExtra("actorTitle", title);
        ActorMessageBox("Searching IMDB to find actor/actress");
        startActivity(intent115);
    }
    public void goToFeedback (View view){
        Intent intent2 = new Intent(this, uk.ac.city.acnh478.courseworkombdapp.feedback.class);
        FeedbackMessageBox("Proceeding to feedback submission screen");
        startActivity(intent2);
    }

}