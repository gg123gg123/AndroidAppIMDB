package uk.ac.city.acnh478.courseworkombdapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class ResActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.results_activity);
        String keyword = getIntent().getExtras().getString("movieTitle");
        keyword = keyword.replaceAll("\\s", "+");

        SQLActivity db = new SQLActivity(this);

        String jsonResult=db.getMovieData(keyword);

        if(jsonResult == null){
            jsonResult = JSONrs(keyword);
            db.insertMovieData(keyword, jsonResult);
        }
        ArrayList<String> searchResultsList = getValuesFromJSON(jsonResult);
        final ListView listView = (ListView) findViewById(R.id.listView);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, searchResultsList);
        listView.setAdapter(arrayAdapter);
    }

    public String JSONrs(String keyword){
        String jsonResult = null;
        try{
            URL url = new URL("http://www.omdbapi.com/?s=" + keyword+ "&y=&plot=short&r=json" );
            HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
            InputStream inputStream = httpURLConnection.getInputStream();
            Scanner scanner = new Scanner(inputStream, "UTF-8").useDelimiter("\\A");
            jsonResult = scanner.hasNext()? scanner.next(): "";
        }catch (Exception e){
            e.printStackTrace();
        }
        return jsonResult;
    }

    private ArrayList<String> getValuesFromJSON(String jsonResult){
        ArrayList<String> Search = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(jsonResult);
            JSONArray jsonArray = jsonObject.getJSONArray("Search");
            for (int i = 0; i<jsonArray.length(); i++) {
                JSONObject result = jsonArray.getJSONObject(i);
                StringBuilder sb = new StringBuilder();
                String ii = String.valueOf(i + 1);
                sb.append(ii);
                sb.append(" , ");
                sb.append(result.getString("Title"));
                sb.append("(");
                sb.append(result.getString("Year"));
                sb.append(")");
                Search.add(sb.toString());
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return Search;
    }

    public void backToSearchActivity(View view){
        Intent intent = new Intent(this, uk.ac.city.acnh478.courseworkombdapp.MainActivity.class);
        startActivity(intent);
    }
}

